let cardData = [
    {
        icon:"fa-brands fa-react",
        cardTitle:"MERN Development"
    },
    {
        icon:"fa-solid fa-server",
        cardTitle:"Backend Development"
    },
    {
        icon:"fa-solid fa-laptop-code",
        cardTitle:"Front End Development"
    },
    {
        icon:"fa-brands fa-uncharted",
        cardTitle:"Web Applications"
    },
    {
        icon:"fa-solid fa-database",
        cardTitle:"Data Base Management"
    },
    {
        icon:"fa-solid fa-mobile-screen",
        cardTitle:"Responisive Design"
    }
]

export default cardData;